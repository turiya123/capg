package com.g3.spc.entities;

public enum ExamType {
	MCQ,DESCRIPTIVE,ANALYTICAL;
	
}
