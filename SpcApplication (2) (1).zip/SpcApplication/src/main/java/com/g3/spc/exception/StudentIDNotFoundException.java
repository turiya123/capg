package com.g3.spc.exception;



public class StudentIDNotFoundException extends Exception {

}
