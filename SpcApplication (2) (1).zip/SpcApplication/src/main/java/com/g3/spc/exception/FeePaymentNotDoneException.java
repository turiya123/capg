package com.g3.spc.exception;

public class FeePaymentNotDoneException  extends Exception{

}
