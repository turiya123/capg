package com.g3.spc.repository;

import java.util.List;

import com.g3.spc.entities.Student;

public interface IStudentRepository {
	public Student addStudent(Student student);
	public Student updateStudent(Student student);
	public Student deleteStudent(Student student);
	public List<Student> retrieveAllStudents();
	public Student retrieveStudentById(int id);
	

}
