package com.g3.spc.repository;

import java.time.LocalDate;

import com.g3.spc.entities.ClassDiary;

public interface IClassDiaryRepository {
	public ClassDiary addClassDiary(ClassDiary classDiary);
	public ClassDiary retrieveClassDiary(LocalDate date);
	
}
