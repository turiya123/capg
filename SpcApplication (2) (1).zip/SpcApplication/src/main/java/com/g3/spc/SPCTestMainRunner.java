package com.g3.spc;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.g3.spc.entities.ClassId;
import com.g3.spc.entities.Exam;
import com.g3.spc.entities.ExamType;
import com.g3.spc.entities.Subject;
import com.g3.spc.entities.Teacher;
public class SPCTestMainRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg = new Configuration();
		SessionFactory factory = cfg.configure().buildSessionFactory(); 
		
		System.out.println("1");
		
		Session session = factory.openSession();// jdbc -> coonection object
		Transaction t = session.beginTransaction();
		
		// ---- write code for data base operation ----
		/*Subject subject = new Subject(201,"Math");
		Exam e = new Exam();
		e.setSubject(subject);
	    e.setMaxMarks(75);
		e.setExamType(ExamType.DESCRIPTIVE);
		e.setDateTimeOfExam(LocalDateTime.parse("2021-04-23T10:30:00"));*/
			
		Subject s1 = new Subject(203,"Intro to programming");
		Subject s2 = new Subject(204,"Physics");
		Subject s3 = new Subject(205,"Biology");
		Subject s4 = new Subject(207,"Math");
		
		Teacher t1 = new Teacher();//Class teacher
		t1.setName("Kevin");
		t1.setSubject(s1);
		t1.setTeacherId(1);

		
		Teacher t2 = new Teacher();
		t2.setName("Chris");
		t2.setSubject(s2);
		t2.setTeacherId(2);
		

		
		Teacher t3 = new Teacher();
		t3.setName("Felix");
		t3.setSubject(s3);
		t3.setTeacherId(3);

		
		Teacher t4 = new Teacher();
		t4.setName("Varsha");
		t4.setSubject(s4);
		t4.setTeacherId(6);

		
		List<Teacher> subjectTeachers = new ArrayList<Teacher>();
		subjectTeachers.add(t2);
		subjectTeachers.add(t3);
		subjectTeachers.add(t4);
		
		ClassId class1 = new ClassId(4,'B');
		class1.setClassTeacher(t1);
		class1.setSubjectTeachers(subjectTeachers);
		
		List<Teacher> subjectTeachers2 = new ArrayList<Teacher>();
		subjectTeachers.add(t2);
		subjectTeachers.add(t1);
		subjectTeachers.add(t4);
		
		ClassId class2 = new ClassId(7,'A');
		class2.setClassTeacher(t3);
		class2.setSubjectTeachers(subjectTeachers2);
		
		List<Teacher> subjectTeachers3 = new ArrayList<Teacher>();
		subjectTeachers.add(t2);
		subjectTeachers.add(t1);
		subjectTeachers.add(t3);
		
		ClassId class3 = new ClassId(5,'C');
		class3.setClassTeacher(t4);
		class3.setSubjectTeachers(subjectTeachers3);
		
		List<ClassId> classlist = new ArrayList<ClassId>();
		classlist.add(class1);
		classlist.add(class2);
		classlist.add(class3);

        Exam e = new Exam();
		e.setClassId(classlist);
		e.setSubject(s1);
	    e.setMaxMarks(75);
		e.setExamType(ExamType.DESCRIPTIVE);
		e.setDateTimeOfExam(LocalDateTime.parse("2021-04-23T10:30:00"));
		
		List<ClassId> classlist2 = new ArrayList<ClassId>();
		classlist2.add(class1);
		
		
		Exam e2 = new Exam();
		e2.setClassId(classlist2);
		e2.setSubject(s3);
	    e2.setMaxMarks(25);
		e2.setExamType(ExamType.MCQ);
		e2.setDateTimeOfExam(LocalDateTime.parse("2022-07-23T10:30:00"));
		
		
		/*session.save(class1);
		session.save(class2);*/
		session.save(e);

		session.save(e2);



		
		
		
		//session.save(e);  // insert into Account .....
		
		System.out.println("  -->> Data Saved ..");
		t.commit();
		
		
		
		
		
		session.close();
	}

}
