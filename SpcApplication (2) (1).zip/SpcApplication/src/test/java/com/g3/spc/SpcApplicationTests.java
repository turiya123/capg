package com.g3.spc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpcApplicationTests {

	@Test
	void contextLoads() {
	}

}
