package com.g3.spc.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.g3.spc.entities.ClassId;
import com.g3.spc.entities.Exam;
import com.g3.spc.entities.ExamType;
import com.g3.spc.entities.Fee;
import com.g3.spc.entities.FeeInstallment;
import com.g3.spc.entities.Subject;
import com.g3.spc.entities.Teacher;
import com.g3.spc.exception.ExamIdNotFoundException;
import com.g3.spc.repository.IExamRepository;



@SpringBootTest
public class IExamServiceImplTest {


	IExamRepository examrepo;
	
	private static IExamServiceImpl ExamService;
	private static AutoCloseable ac;
	
	@BeforeEach
	public void doinit() {
		examrepo = mock(IExamRepository.class);
		
		
		ExamService = new IExamServiceImpl(examrepo);
		ac = MockitoAnnotations.openMocks(this);
		
	}
	@AfterEach
	public void doEnd() throws Exception{
		ac.close();
	}
	
	
	//@Disabled
	
	@Test
	//@Disabled
	@DisplayName("Test-Save Exam")
	void testSaveExam(){
		
		Subject s = new Subject(201,"Math");
		Subject s1 = new Subject(202,"Phy");
		Subject s2 = new Subject(203,"Dance");
		List <Teacher> sub = new ArrayList<>();
		Teacher ct = new Teacher(1,"Chris",s);
		ClassId c = new ClassId("2A",2,'A', ct, sub);
		ClassId c1 = new ClassId("3A",3,'A', ct, sub);
		List <ClassId> cl = new ArrayList<>();

	//	ExamType et = new ExamType.MCQ");
		Exam input = new Exam(1,cl,LocalDateTime.of(2022, 03, 13, 10, 30, 00),s,ExamType.MCQ,100);
		Exam expected1 = new Exam(1,cl,LocalDateTime.of(2022, 03, 13, 10, 30, 00),s,ExamType.MCQ,100);

	
		when(examrepo.save(input)).thenReturn(expected1);
		Exam output =  ExamService.addExam(input);
		verify(examrepo).save(input);
		assertEquals(expected1,output);
	}
	
	
	
	
	@Test
	//@Disabled
	@DisplayName("Testing Delete Exam")
	void testingdeleteExam() throws ExamIdNotFoundException {
		
		Subject s = new Subject(201,"Math");
		Subject s1 = new Subject(202,"Phy");
		Subject s2 = new Subject(203,"Dance");
		List <Teacher> sub = new ArrayList<>();
		Teacher ct = new Teacher(1,"Chris",s);
		ClassId c = new ClassId("2A",2,'A', ct, sub);
		ClassId c1 = new ClassId("3A",3,'A', ct, sub);
		List <ClassId> cl = new ArrayList<>();

	//	ExamType et = new ExamType.MCQ");
		Exam input1 = new Exam(1,cl,LocalDateTime.of(2022, 03, 13, 10, 30, 00),s,ExamType.MCQ,100);
		Exam expected2 = new Exam(1,cl,LocalDateTime.of(2022, 03, 13, 10, 30, 00),s,ExamType.MCQ,100);
		try {
			doNothing().when(examrepo).delete(expected2);
			Exam output  = ExamService.deleteExam(input1);
			verify(examrepo).delete(input1);
			assertEquals(expected2,output);
			
		} catch (ExamIdNotFoundException e ) {
			// TODO: handle exception
			
			
		}
	
	}
	
	@Test
	//@Disabled
	@DisplayName("Testing Update Exam")

	void testupdateExam() throws ExamIdNotFoundException{
		Subject s = new Subject(201,"Math");
		Subject s1 = new Subject(202,"Phy");
		Subject s2 = new Subject(203,"Dance");
		List <Teacher> sub = new ArrayList<>();
		Teacher ct = new Teacher(1,"Chris",s);
		ClassId c = new ClassId("2A",2,'A', ct, sub);
		ClassId c1 = new ClassId("3A",3,'A', ct, sub );
		List <ClassId> cl = new ArrayList<>();

	//	ExamType et = new ExamType.MCQ");
		Exam input1 = new Exam(1,cl,LocalDateTime.of(2022, 03, 13, 10, 30, 00),s,ExamType.MCQ,100);
		input1.setExamId(3);		
		try {
			when(examrepo.findById(3)).thenReturn(Optional.of(input1));
			Exam output = ExamService.updateExam(input1);
			assertEquals(input1,output);
			
		} catch (ExamIdNotFoundException e ) {
			// TODO: handle exception
			
			
		}
		
		
	}
	
	
  
	
	@Test
	//@Disabled
	@DisplayName("Test-Save Exam")
	void InvalidtestSaveExam(){
		
		Subject s = new Subject(201,"Math");
		Subject s1 = new Subject(202,"Phy");
		Subject s2 = new Subject(203,"Dance");
		List <Teacher> sub = new ArrayList<>();
		Teacher ct = new Teacher(1,"Chris",s);
		ClassId c = new ClassId("2A",2,'A', ct, sub);
		ClassId c1 = new ClassId("3A",3,'A', ct, sub);
		List <ClassId> cl = new ArrayList<>();

	//	ExamType et = new ExamType.MCQ");
		Exam input = new Exam(1,cl,LocalDateTime.of(2022, 03, 13, 10, 30, 00),s,ExamType.MCQ,100);
		Exam expected1 = new Exam(1,cl,LocalDateTime.of(2022, 03, 13, 10, 30, 00),s,ExamType.MCQ,100);

	
		when(examrepo.save(input)).thenReturn(expected1);
		Exam output =  ExamService.addExam(input);
		verify(examrepo).save(input);
		assertEquals(expected1,output);
	}
	
	
	
}
