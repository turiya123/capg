package com.cg.spc.exception;



public class StudentIDNotFoundException extends Exception {

}
