package com.cg.spc.entities;

import java.time.LocalDate;

public class FeeInstallment {
private int feeInstallmentId;
private double feeInstallment;
private LocalDate dueDate;
private LocalDate feePaymentDate;
private Fee fee;

}
