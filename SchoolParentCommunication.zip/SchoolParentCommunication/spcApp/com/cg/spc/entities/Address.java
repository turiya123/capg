package com.cg.spc.entities;

public class Address {
	private String buildingName;
	private String streetName;
	private String cityName;
	private String pincode;
	
}
