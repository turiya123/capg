package com.cg.spc.entities;

import java.time.LocalDate;
import java.util.Map;

public class ClassDiary {
	private int classDiaryId;
	private Map<LocalDate,DiaryNotes> diaryNotes;
	
	
}
