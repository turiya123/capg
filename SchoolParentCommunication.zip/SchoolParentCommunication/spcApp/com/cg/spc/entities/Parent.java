package com.cg.spc.entities;

public class Parent {
	private int parentId;
	private Student student;
	private String mobileNumber;
	private String emailId;
	
}
