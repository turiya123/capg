package com.cg.spc.entities;

import java.util.Map;

public class DiaryNotes {
	private int diaryNotesId;
	private Map<Subject,String> notes;
	
}
