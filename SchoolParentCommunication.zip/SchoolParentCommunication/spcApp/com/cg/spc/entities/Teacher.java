package com.cg.spc.entities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Teacher {
	private int teacherId;
	private String name;
	private Map<Subject,List<ClassId>> subjectClasses;
	
	
}
