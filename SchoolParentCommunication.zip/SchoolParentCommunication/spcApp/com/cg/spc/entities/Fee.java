package com.cg.spc.entities;

import java.time.LocalDate;

public class Fee {
	private int FeeId;
	private Student student;
	private double totalFeesDue;
	private double totalFeesReceived;
	private LocalDate startMonthYear;
	private LocalDate endMonthYear;
	
	
	
	//incomplete
	
	

	
}
