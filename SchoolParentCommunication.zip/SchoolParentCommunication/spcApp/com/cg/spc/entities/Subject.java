package com.cg.spc.entities;

public class Subject {
	private int subjectId;
	private String title;
	
}
