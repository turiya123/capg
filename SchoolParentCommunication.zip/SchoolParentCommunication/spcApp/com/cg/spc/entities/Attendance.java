package com.cg.spc.entities;

import java.time.LocalDate;

public class Attendance {
	private int attendanceId;
	private Student student;
	private LocalDate dateOfClass;
	private boolean present;
	
	
	
}
