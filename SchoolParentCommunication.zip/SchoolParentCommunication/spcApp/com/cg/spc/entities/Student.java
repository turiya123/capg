package com.cg.spc.entities;

import java.time.LocalDate;
import java.util.List;

public class Student {
	private long userId;
	private LocalDate dateOfBirth;
	private ClassId currentClass;
	private List<Subject> subjects;
	private String name;
	private Address address;
	private ClassDiary classDiary;
	private String emailId;
	private String mobileNumber;
	
	
	
}
