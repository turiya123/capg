package com.cg.spc.entities;

public class Admin {
private int userId;
private String adminName;
private String adminContact;
}
