package com.cg.spc.entities;

import java.time.LocalDateTime;

public class Exam {
	private int examId;
	private ClassId classId;
	private LocalDateTime dateTimeOfExam;
	private Subject subject;
	private ExamType  examType;
	private int maxMarks;
	
	
	
	
}
