package Lab6;

public class Count2 {

}
