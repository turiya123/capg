package Lab5.ex3;

public class ValidSalaryException extends Exception{

	public ValidSalaryException(String sal) {
		super(sal);
		// TODO Auto-generated method stub

	}

}
