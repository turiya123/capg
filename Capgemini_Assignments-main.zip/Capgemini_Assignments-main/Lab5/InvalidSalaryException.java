package Lab5.ex3;

public class InvalidSalaryException extends Exception {

	public InvalidSalaryException(String sal) {
		super(sal);
		// TODO Auto-generated method stub

	}

}
