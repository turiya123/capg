package Lab5;

public class ValidAgeException extends Exception{

	public ValidAgeException(String s)  {
		super(s);
		// TODO Auto-generated method stub

	}

}
