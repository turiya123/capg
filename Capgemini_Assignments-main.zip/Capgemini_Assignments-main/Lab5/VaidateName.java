package Lab5.ex3;

public class VaidateName {

}
