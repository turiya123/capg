package Lab5;

public class InvalidAgeException extends Exception {

	public InvalidAgeException(String s) {
		super(s);
		// TODO Auto-generated method stub

	}

}
