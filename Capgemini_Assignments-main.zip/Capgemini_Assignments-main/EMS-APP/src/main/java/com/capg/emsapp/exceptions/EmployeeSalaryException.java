package com.capg.emsapp.exceptions;

public class EmployeeSalaryException extends Exception {

}
