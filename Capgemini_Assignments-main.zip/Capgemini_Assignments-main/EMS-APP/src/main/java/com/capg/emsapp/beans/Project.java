package com.capg.emsapp.beans;

public class Project {

	private String projectTitle;
	private String projectTechnology;
	public String getProjectTitle() {
		return projectTitle;
	}
	public void setProjectTitle(String projectTitle) {
		this.projectTitle = projectTitle;
	}
	public String getProjectTechnology() {
		return projectTechnology;
	}
	public void setProjectTechnology(String projectTechnology) {
		this.projectTechnology = projectTechnology;
	}
	
}
