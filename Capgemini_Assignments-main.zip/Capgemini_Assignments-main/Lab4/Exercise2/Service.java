package Lab4.ex2;

public interface Service {
	public void getEmployeeDetails();
	public void findInsuranceschema(double salary);
	public void displayEmpDetails();
	
}