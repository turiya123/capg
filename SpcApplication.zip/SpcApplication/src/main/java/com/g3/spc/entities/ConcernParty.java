package com.g3.spc.entities;

public enum ConcernParty {
TEACHER,ACCOUNTANT,PRINCIPAL,TRANSPORTOFFICER,CATERER;
}
