package com.g3.spc.entities;

public class Address {
	private String buildingName;
	private String streetName;
	private String cityName;
	private String pincode;
	
}
