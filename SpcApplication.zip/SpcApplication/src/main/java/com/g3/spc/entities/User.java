package com.g3.spc.entities;

public class User {
private int userId;
private String password;
private String role;

}
