package com.g3.spc.entities;

public class StudentExamAttempt {
	private int studentExamAttemptId;
	private Student student;
	private Exam exam;
	private boolean attempted;
	private int marksObtained;
	
}
