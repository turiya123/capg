package com.g3.spc.entities;

public class Parent {
	private int parentId;
	private Student student;
	private String mobileNumber;
	private String emailId;
	
}
