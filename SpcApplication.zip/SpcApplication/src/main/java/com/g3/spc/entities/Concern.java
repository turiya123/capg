package com.g3.spc.entities;

public class Concern {
	private int concernId;
	private Parent parent;
	private ConcernType concernType;
	private String concernDescription;
	private ConcernParty concernParty;
	private boolean resolved;
	
	
	
}
